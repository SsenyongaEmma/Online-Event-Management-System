from django.db import models
# Create your models here.

class Events(models.Model):
    title = models.CharField(max_length=1000)
    description = models.CharField(max_length=2000)