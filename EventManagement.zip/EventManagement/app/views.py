from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    
    return render(request, 'index.html')

# def login(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
    
    return render(request, 'login.html')

def login(request):
 
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
    
        user = auth.authenticate(username=username, password=password)
       
        if user is not None:
            auth.login(request, user)
            if User:
                return redirect('index')
            
            #  Check if user profile exists, create if not
        
            # user_profile, created = UserProfile.objects.get_or_create(user=user)
            # # Check if room details have been filled
            # if user_profile.room_details_filled:
            #     # Room details already filled, redirect to the main page
            #     return redirect('main')
            # else:
            #     # Room details not filled, redirect to the room details page
            #     return redirect('index')
        
        elif not username:
            messages.info(request, "Must include username")
            return redirect('login')
        
        elif not password:
            messages.info(request, "Must include password")
            return redirect('login')
        else:
            messages.info(request, "Invalid Credentials")
            return redirect('login')
    else:
        return render(request, 'login.html')
   


# def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password1']
        password2 = request.POST['password2']
        
        # Check if the password1 == password2
        if password == password2:
            if User.objects.filter(email=email).exists():
                message.info('email already exists')  
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            user.save()
            print('User:' + username + 'is created')
            return redirect('login')

    return render(request, 'register.html')

def register(request):
    
    
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password1"]
        password2 = request.POST["password2"]
        
        # check if the user has filled in the required fields 
        if password == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request, "Email already exists")
                return redirect("register")
            
            elif User.objects.filter(username=username).exists():
                messages.info(request, "Username already used")
                return redirect("register")
            elif not username:
                messages.info(request, "Must include username")
                return redirect('register')
                
            elif not email:
                messages.info(request, "Must include email")
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save();
                return redirect('index')
        else:
            messages.info(request, "Password is not the same")
            return redirect('register')
    else:
            return render(request, 'register.html')


def dashboard(request):
    
    return render(request, 'dashboard.html')

def events(request):
    
    return render(request, 'events.html')

def promotion_tools(request):
    
    return render(request, 'promotion_tools.html')

def payment(request):
    
    return render(request, 'payment.html')
    